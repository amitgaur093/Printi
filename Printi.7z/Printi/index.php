<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Amit App</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">

        <!--Add java script-->
        <script src="js/jquery/jquery-3.2.1.min.js"></script>
        <script src="js/jquery_ui/jquery-ui.min.js"></script>
        <script src="js/bootstrap/bootstrap.js"></script>
        <script src="dist/jquery.inputmask.bundle.js"></script>
        <script src="dist/inputmask/phone-codes/phone.js"></script>
        <script src="dist/inputmask/phone-codes/phone-be.js"></script>
        <script src="dist/inputmask/phone-codes/phone-ru.js"></script>

        <!--Add stylesheets-->
        <link rel="stylesheet" type="text/css" href="stylesheets/bootstrap/bootstrap-responsive.css">
        <link rel="stylesheet" type="text/css" href="stylesheets/bootstrap/bootstrap.css">
    </head>

    <body>
        <div id="searchDiv">
            <form action="<?php $_SERVER['PHP_SELF'] ?>" enctype="multipart/form-data" method="post" name="frmSearchFrms">
                <div id="originZip">
                    <label for="origin">Origin Zip Code</label>
                    <input type="text" id="origin" name="origin" required="true">
                </div>
                <div id="destZip">
                    <label for="dest">Destination Zip Code</label>
                    <input type="text" id="dest" name="dest" required="true">
                </div>
                <div id="weightDiv">
                    <label for="weight">Weight</label>
                    <input type="text" id="weight" name="weight" required="true">
                </div>
                <div id="goodsCost">
                    <label for="cost">Cost of Goods</label>
                    <input type="text" id="cost" name="cost" required="true">
                </div>
                <div id="widthDiv">
                    <label for="width">Width</label>
                    <input type="text" id="width" name="width" required="true">
                </div>
                <div id="heightDiv">
                    <label for="height">Height</label>
                    <input type="text" id="height" name="height" required="true">
                </div>
                <div id="lengthDiv">
                    <label for="length">Length</label>
                    <input type="text" id="length" name="length" required="true">
                </div>
                <div id="calculate"><input type="submit" value="Calculate" id="submit" name="submit" ></div>
            </form>
        </div>

        <div id="displayDiv">
            <table id="displayResult">
                <thead>
                <th></th>
                <th>Estimate Business Days</th>
                <th>Shipping Cost</th>
                <th>Description</th>
                </thead>
                <tbody></tbody>
            </table>
        </div>

        <script type="text/javascript">

            $(function() {
                $('#searchDiv').show();
                $('#displayDiv').hide();
                $('#origin').inputmask("99999-999");
                $('#dest').inputmask("99999-999");
                $('#weight').inputmask({'mask': "9{0,5}.9{0,2}", greedy: false});
                $('#cost').inputmask({'mask': "9{0,5}.9{0,2}", greedy: false});
                $('#width').inputmask({'mask': "99999", greedy: false});
                $('#height').inputmask({'mask': "99999", greedy: false});
                $('#length').inputmask({'mask': "99999", greedy: false});

                $('#submit').click(function(e) {
                    e.preventDefault();
                    if($('#origin').val() == ''){
                        alert('Origin can not be blank');
                        return false;
                    } else if($('#dest').val() == ''){
                        alert('Destination can not be blank');
                        return false;
                    } else if($('#weight').val() == ''){
                        alert('Weight can not be blank');
                        return false;
                    }else if($('#cost').val() == ''){
                        alert('Cost can not be blank');
                        return false;
                    }else if($('#width').val() == ''){
                        alert('Width can not be blank');
                        return false;
                    }else if($('#height').val() == ''){
                        alert('Height can not be blank');
                        return false;
                    }else if($('#length').val() == ''){
                        alert('Length can not be blank');
                        return false;
                    }else if ($('#origin').val() == $('#dest').val()) {
                        alert('Origin and Destination can not be same');
                        return false;
                    } else {
                        $.post("Ajaxcall.php", {origin_zip_code: $('#origin').val(), destination_zip_code: $('#dest').val(), weight: $('#weight').val(),
                            cost_of_goods: $('#cost').val(), width: $('#width').val(), height: $('#height').val(), length: $('#length').val()}, function(data) {
                            console.log(data);
                            $.each(data, function(i, item) {
                                tableData = '<tr>' +
                                        '<td style="width: 25px; text-align: center;"><input type="checkbox" class="chck" name="chck" value="' +
                                        item.description + ', ' + item.final_shipping_cost + ' $, ' + item.delivery_estimate_business_days + ' day"></td>' +
                                        '<td style="width: 25px; text-align: center;">' + data[i].delivery_estimate_business_days + '</td>' +
                                        '<td style="width: 25px; text-align: center;">' + data[i].final_shipping_cost + '</td>' +
                                        '<td style="width: 25px;">' + data[i].description + '</td>' +
                                        '</tr>';
                                $("#displayResult tbody").append(tableData);
                            });
                            okbtn = '<input type="button" id="okbtn" name="okbtn" value="OK">';
                            $("#displayResult tbody").append(okbtn);
                            $('#searchDiv').hide();
                            $('#displayDiv').show();

                            $('.chck').on("change", function() {
                                $('.chck').not(this).prop('checked', false);
                                var checkedValue = null;
                                var inputElements = document.getElementsByClassName('chck');
                                for (var i = 0; inputElements[i]; ++i) {
                                    if (inputElements[i].checked) {
                                        checkedValue = inputElements[i].value;
                                        break;
                                    }
                                }
                                console.log(checkedValue);
                                alert(checkedValue);
                            });
                        });
                    }
                });



            });
        </script>
    </body>
</html>