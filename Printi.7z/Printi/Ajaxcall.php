<?php

function fetchDetails() {
    
   
    $origin = $_POST['origin_zip_code'];
    $dest = $_POST['destination_zip_code'];
    $weight = $_POST['weight'];
    $cost = $_POST['cost_of_goods'];
    $width = str_replace('_','',$_POST['width']);
    $height = str_replace('_','',$_POST['height']);
    $length = str_replace('_','',$_POST['length']);
    
    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://api.intelipost.com.br/api/v1/quote_by_product",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_PROXY => 'webproxy401:8080',
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => "{\"origin_zip_code\":\"" . $origin . "\",\"destination_zip_code\":\"" . $dest . "\",\"products\":[{\"weight\":" . $weight . ","
        . "\"cost_of_goods\":" . $cost . ",\"width\":" . $width . ",\"height\":" . $height . ",\"length\":" . $length . "}]}",
        CURLOPT_HTTPHEADER => array(
            "api_key: 9009f95101bf48b01a50928a2a71ed1ae9083fc1d3c08439b0613dfc38e656c5",
            "content-type: application/json"
        ),
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);
    
    $json = json_decode($response, TRUE);
    $content = $json['content']['delivery_options'];
   
    foreach($content as $key => $value){
        $data[] = array(
            'delivery_method_id' => $value['delivery_method_id'],
            'delivery_estimate_business_days' => $value['delivery_estimate_business_days'],
            'final_shipping_cost' => $value['final_shipping_cost'],
            'description' => $value['description']
        );
    }

    curl_close($curl);

    if ($err) {
        echo "cURL Error #:" . $err;
    } else {
        header('Content-type: application/json');
        echo json_encode($data);
    }
}

fetchDetails();

?>